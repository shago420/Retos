def es_palindromo(palabra):
    # Eliminamos espacios y convertimos todo a minúsculas para evitar problemas de capitalización
    palabra = palabra.replace(" ", "").lower()
    
    # Comparamos la palabra original con su reverso
    return palabra == palabra[::-1]

# Solicitamos la palabra al usuario
palabra_usuario = input("Ingrese una palabra: ")

if es_palindromo(palabra_usuario):
    print(f"{palabra_usuario} es un palíndromo.")
else:
    print(f"{palabra_usuario} no es un palíndromo.")
